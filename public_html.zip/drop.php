<?php

//include module
require './lib/db.php';



?>
